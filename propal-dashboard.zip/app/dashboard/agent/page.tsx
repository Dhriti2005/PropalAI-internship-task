"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Settings, Mic, Globe, Cpu } from "lucide-react"

interface STTConfig {
  providers: {
    [key: string]: {
      name: string
      models: {
        [key: string]: {
          name: string
          languages: {
            [key: string]: string
          }
        }
      }
    }
  }
}

const fallbackConfig: STTConfig = {
  providers: {
    deepgram: {
      name: "Deepgram",
      models: {
        "nova-2": {
          name: "Nova-2",
          languages: {
            "en-US": "English (US)",
            "en-GB": "English (UK)",
            "es-ES": "Spanish (Spain)",
          },
        },
      },
    },
    openai: {
      name: "OpenAI Whisper",
      models: {
        "whisper-1": {
          name: "Whisper v1",
          languages: {
            en: "English",
            es: "Spanish",
            fr: "French",
          },
        },
      },
    },
  },
}

export default function AgentPage() {
  const [config, setConfig] = useState<STTConfig | null>(null)
  const [selectedProvider, setSelectedProvider] = useState("")
  const [selectedModel, setSelectedModel] = useState("")
  const [selectedLanguage, setSelectedLanguage] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Load config from JSON file
    const fetchConfig = async () => {
      try {
        setLoading(true)

        // First try to fetch from public directory
        let res = await fetch("/stt.json")

        // If that fails, try the API endpoint
        if (!res.ok) {
          console.log("Fetching from API endpoint instead")
          res = await fetch("/api/config/stt")

          if (!res.ok) {
            throw new Error(`Failed to fetch from both sources`)
          }
        }

        const data = await res.json()
        setConfig(data)

        // Load saved selections from localStorage
        const savedProvider = localStorage.getItem("stt-provider")
        const savedModel = localStorage.getItem("stt-model")
        const savedLanguage = localStorage.getItem("stt-language")

        if (savedProvider && data.providers[savedProvider]) {
          setSelectedProvider(savedProvider)
          if (savedModel && data.providers[savedProvider].models[savedModel]) {
            setSelectedModel(savedModel)
            if (savedLanguage && data.providers[savedProvider].models[savedModel].languages[savedLanguage]) {
              setSelectedLanguage(savedLanguage)
            }
          }
        }
      } catch (err) {
        console.error("Failed to load STT config:", err)
        // Provide fallback configuration
        setConfig(fallbackConfig)
      } finally {
        setLoading(false)
      }
    }

    fetchConfig()
  }, [])

  const handleProviderChange = (provider: string) => {
    setSelectedProvider(provider)
    setSelectedModel("")
    setSelectedLanguage("")
    localStorage.setItem("stt-provider", provider)
    localStorage.removeItem("stt-model")
    localStorage.removeItem("stt-language")
  }

  const handleModelChange = (model: string) => {
    setSelectedModel(model)
    setSelectedLanguage("")
    localStorage.setItem("stt-model", model)
    localStorage.removeItem("stt-language")
  }

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language)
    localStorage.setItem("stt-language", language)
  }

  const getAvailableModels = () => {
    if (!config || !selectedProvider) return []
    return Object.entries(config.providers[selectedProvider].models)
  }

  const getAvailableLanguages = () => {
    if (!config || !selectedProvider || !selectedModel) return []
    return Object.entries(config.providers[selectedProvider].models[selectedModel].languages)
  }

  if (loading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Agent Configuration</h1>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Configuration Panel */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                STT Configuration
              </CardTitle>
              <CardDescription>Configure your speech-to-text settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Provider Selection */}
              <div className="space-y-2">
                <Label>Provider</Label>
                <Select value={selectedProvider} onValueChange={handleProviderChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a provider" />
                  </SelectTrigger>
                  <SelectContent>
                    {config &&
                      Object.entries(config.providers).map(([key, provider]) => (
                        <SelectItem key={key} value={key}>
                          {provider.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Model Selection */}
              <div className="space-y-2">
                <Label>Model</Label>
                <Select value={selectedModel} onValueChange={handleModelChange} disabled={!selectedProvider}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableModels().map(([key, model]) => (
                      <SelectItem key={key} value={key}>
                        {model.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Language Selection */}
              <div className="space-y-2">
                <Label>Language</Label>
                <Select value={selectedLanguage} onValueChange={handleLanguageChange} disabled={!selectedModel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a language" />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableLanguages().map(([key, language]) => (
                      <SelectItem key={key} value={key}>
                        {language}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Summary Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mic className="h-5 w-5 mr-2" />
                Configuration Summary
              </CardTitle>
              <CardDescription>Current STT configuration overview</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedProvider && selectedModel && selectedLanguage ? (
                <>
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Cpu className="h-4 w-4 text-blue-600" />
                      <span className="font-medium">Provider:</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{config?.providers[selectedProvider].name}</div>
                      <Badge variant="secondary" className="text-xs">
                        {selectedProvider}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Settings className="h-4 w-4 text-green-600" />
                      <span className="font-medium">Model:</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">
                        {config?.providers[selectedProvider].models[selectedModel].name}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {selectedModel}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Globe className="h-4 w-4 text-purple-600" />
                      <span className="font-medium">Language:</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">
                        {config?.providers[selectedProvider].models[selectedModel].languages[selectedLanguage]}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {selectedLanguage}
                      </Badge>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <Mic className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select provider, model, and language to see configuration summary</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
