import { type NextRequest, NextResponse } from "next/server"
import fs from "fs"
import path from "path"
import { v4 as uuidv4 } from "uuid"

interface User {
  id: string
  username: string
  email: string
  password: string
  phone?: string
}

export async function POST(request: NextRequest) {
  try {
    const { username, email, password, phone } = await request.json()

    // Validate required fields
    if (!username || !email || !password) {
      return NextResponse.json({ error: "Username, email, and password are required" }, { status: 400 })
    }

    const usersFilePath = path.join(process.cwd(), "public", "users.json")

    // Read existing users or create empty array
    let users: User[] = []
    try {
      const usersData = fs.readFileSync(usersFilePath, "utf8")
      users = JSON.parse(usersData)
    } catch (error) {
      // File doesn't exist, start with empty array
      users = []
    }

    // Check if user already exists
    const existingUser = users.find((user) => user.email === email)
    if (existingUser) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 400 })
    }

    // Create new user
    const newUser: User = {
      id: uuidv4(),
      username,
      email,
      password, // In production, hash this password
      phone: phone || undefined,
    }

    users.push(newUser)

    // Write back to file
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2))

    // Return user without password
    const { password: _, ...userWithoutPassword } = newUser
    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
