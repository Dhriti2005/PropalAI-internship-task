import { type NextRequest, NextResponse } from "next/server"
import fs from "fs"
import path from "path"

interface User {
  id: string
  username: string
  email: string
  password: string
  phone?: string
}

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const usersFilePath = path.join(process.cwd(), "public", "users.json")

    // Read users file
    let users: User[] = []
    try {
      const usersData = fs.readFileSync(usersFilePath, "utf8")
      users = JSON.parse(usersData)
    } catch (error) {
      return NextResponse.json({ error: "No users found" }, { status: 400 })
    }

    // Find user
    const user = users.find((u) => u.email === email && u.password === password)
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Return user without password
    const { password: _, ...userWithoutPassword } = user
    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
