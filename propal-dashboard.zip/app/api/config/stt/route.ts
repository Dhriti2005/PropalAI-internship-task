import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

export async function GET() {
  try {
    const configPath = path.join(process.cwd(), "public", "stt.json")

    // Check if file exists
    if (!fs.existsSync(configPath)) {
      // Return fallback config if file doesn't exist
      return NextResponse.json({
        providers: {
          deepgram: {
            name: "Deepgram",
            models: {
              "nova-2": {
                name: "Nova-2",
                languages: {
                  "en-US": "English (US)",
                  "en-GB": "English (UK)",
                  "es-ES": "Spanish (Spain)",
                },
              },
            },
          },
          openai: {
            name: "OpenAI Whisper",
            models: {
              "whisper-1": {
                name: "Whisper v1",
                languages: {
                  en: "English",
                  es: "Spanish",
                  fr: "French",
                },
              },
            },
          },
        },
      })
    }

    // Read the file
    const configData = fs.readFileSync(configPath, "utf8")
    const config = JSON.parse(configData)

    return NextResponse.json(config)
  } catch (error) {
    console.error("Error loading STT config:", error)
    return NextResponse.json({ error: "Failed to load configuration" }, { status: 500 })
  }
}
