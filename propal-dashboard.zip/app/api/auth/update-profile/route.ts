import { type NextRequest, NextResponse } from "next/server"
import fs from "fs"
import path from "path"

interface User {
  id: string
  username: string
  email: string
  password: string
  phone?: string
}

export async function PUT(request: NextRequest) {
  try {
    const { userId, email, password, phone } = await request.json()

    if (!userId || !email) {
      return NextResponse.json({ error: "User ID and email are required" }, { status: 400 })
    }

    const usersFilePath = path.join(process.cwd(), "public", "users.json")

    // Read users file
    let users: User[] = []
    try {
      const usersData = fs.readFileSync(usersFilePath, "utf8")
      users = JSON.parse(usersData)
    } catch (error) {
      return NextResponse.json({ error: "Users file not found" }, { status: 400 })
    }

    // Find user index
    const userIndex = users.findIndex((u) => u.id === userId)
    if (userIndex === -1) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Update user
    users[userIndex] = {
      ...users[userIndex],
      email,
      phone: phone || users[userIndex].phone,
      ...(password && { password }), // Only update password if provided
    }

    // Write back to file
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2))

    // Return updated user without password
    const { password: _, ...userWithoutPassword } = users[userIndex]
    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Update profile error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
